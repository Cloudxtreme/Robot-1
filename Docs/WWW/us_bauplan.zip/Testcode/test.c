#include "asuro.h"

void LocalInit(void)
{
	// Change Oscillator-frequency of Timer 2
	// to 40kHz, no toggling of IO-pin:
	TCCR2 = (1 << WGM21) | (1 << CS20);
	OCR2 = 0x64;						// 40kHz @8MHz crystal
	ADCSRA = 0x00;					// ADC off
	// Analog comparator:
	ACSR = 0x02;						// Generate interrupt on falling edge
	ADMUX = 0x03;						// Multiplexer for comparator to
													// ADC pin 3
	SFIOR |= (1 << ACME);		// Enable muliplexing of comparator
	DDRD &= ~(1 << 6);			// Port D Pin 6 is input!
}


void Ping(unsigned char length)
{
	count72kHz = 0;
	TCCR2 = (1 << WGM21) | (1 << COM20) | (1 << CS20);
													// Toggling of IO-Pin on
	
	// generate the Chirp
	while(count72kHz < length) {
		OCR2 = 0x64 + length / 2 - count72kHz;
	}
	
	TCCR2 = (1 << WGM21) | (1 << CS20);		// Toggling of IO-Pin off
	OCR2 = 0x64;													// set frequency to 40kHz
}


int main(void)
{
	int pos, i;
	int posmarker;
	Init();
	LocalInit();
	while(TRUE) {
		posmarker = 0;
		Ping(20);
		for(pos = 0; pos < 100; pos++) {
			Sleep(10);
			if((ACSR & (1 << ACI)) != 0) {
				if(posmarker == 0) { posmarker = pos; }
			}
			ACSR |= (1 << ACI);
		}
		if(posmarker > 10) {
			StatusLED(GREEN);
			MotorDir(FWD, FWD);
			MotorSpeed(200, 200);
		}
		else {
			StatusLED(RED);
			MotorDir(FWD, RWD);
			MotorSpeed(0, 200);
			for(i = 0; i<100; i++) { Sleep(200); }
		}
	}
	
	return 0;
}
