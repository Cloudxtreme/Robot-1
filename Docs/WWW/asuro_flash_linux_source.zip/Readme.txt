Mail From Jan Grewe:

>
>I read in the your support forum, that some people have problems to
>compile the Linux Software for ASURO.
>Here are three files to make it very simple to compile this tools.
>(i hope so ;-) )
>
>First one Con_Flash.tar.gz:
>the Consolen Application. All the stuff for KDevelop2.1 is included,
>also configure scripts.
>To compile with KDevelop you have to open the project file for
>KDevelop. To compile it in Console you have to start the configure
>script in the following way:
>"env CPPFALGS="-D_LINUX -D_CONSOLE" ./configure"
>"make all"
>"make install"
>Tested under SUSE Linux 8.1 / 9.3
>
>Second one QT_Flash.tar.zip:
>the QT-Application. All the stuff for KDevelop2.1 is included, also
>configure scripts.
>To compile with KDevelop you have to open the project file for
>KDevelop. To compile it in Console you have to start the configure
>script in the following way:
>"env CPPFALGS="-D_LINUX -D_QT" ./configure"
>"make all"
>"make install"
>the qt-devel pakage must be installed. A running X-System  is
>necessary and you need aclocal, aconfig, amake version1.6
>Tested under SUSE Linux 8.1 don't work under SUSE Linux 9.3 in that easy way.
>
>
>Third one qt_flashdialog.tar.gz:
>QT-Applikation  with all the stuff for KDevelop3.2.
>To compile with KDevelop you have to open the project file for
>KDevelop. To compile it in Console you have type: "make all". The
>makefile in this case are generated with qmake, available in Version3 of QT.
>You have to install the qt3-devel pakage and a running X-System.
>To install qmake type in root-Console:
>"ln -s /usr/lib/qt3/bin/qmake /usr/bin"
>If compiling under Console be sure that the CXXFLAGS are set to
>"-D_LINUX -D_QT"
>Tested under SUSE Linux 9.3
>
>Best regards
>Jan Grewe
>
