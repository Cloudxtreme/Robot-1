#include "asuro.h"

int main(void)
{
	Init();
	
	while(1);
	return 0;
}
