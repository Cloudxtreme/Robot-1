/* *******************************************************************
 *
 * SubCtl_2Sonic.h
 *
 * (C) 2014 Dreamshader (Dirk Schanz)
 *
 * control of an ultrasonic subcontroller (pro mini with two us-sensors)
 *     definitions and prototypes
 *
 * -------------------------------------------------------------------
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *******************************************************************
*/

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _SUBCTL2SONIC_H_
#define _SUBCTL2SONIC_H_

//
// constant definitions
//

#define CMD2SONIC_GET_DIRECTION		 1
#define CMD2SONIC_GET_DISTANCE		 2
#define CMD2SONIC_GET_CONDITION		 3
#define CMD2SONIC_SET_COND_R_DIST	 4
#define CMD2SONIC_SET_COND_Y_DIST	 5
#define CMD2SONIC_SET_COND_G_DIST	 6
#define CMD2SONIC_GET_COND_R_DIST	 7
#define CMD2SONIC_GET_COND_Y_DIST	 8
#define CMD2SONIC_GET_COND_G_DIST	 9
#define CMD2SONIC_SET_DIR_FORWARD	10
#define CMD2SONIC_SET_DIR_BACK		11
#define CMD2SONIC_SET_INTERVAL		12
#define CMD2SONIC_GET_INTERVAL		13
#define CMD2SONIC_SET_DIR_RIGHT		14
#define CMD2SONIC_SET_DIR_LEFT		15
#define CMD2SONIC_USER			16
#define CMD2SONIC_STOP			17
#define CMD2SONIC_PAUSE			18
#define CMD2SONIC_CONTINUE		19
#define CMD2SONIC_EXIT			20
#define CMD2SONIC_STORE_VALUES		21
#define CMD2SONIC_SET_VERBOSE		22
#define CMD2SONIC_SET_DIRECTION		23
#define CMD2SONIC_SET_DISTANCE		24
#define CMD2SONIC_SET_CONDITION		25
#define CMD2SONIC_SET_DEBUG		26
#define CMD2SONIC_RESET_DEFAULTS	27
#define CMD2SONIC_GET_MAXALARM		28
#define CMD2SONIC_SET_MAXALARM		29

#define CONDITION_2SONIC_R		 3
#define CONDITION_2SONIC_Y		 4
#define CONDITION_2SONIC_G		 5
// defaults
// error codes

//
// structures/unions
//
typedef struct _2sonic_command_set_ {
char *cmd;
int cmd_val;
} sonic2_command_set_t, *p_2sonic_command_set_t;

#define SONIC2PARAM_NONE	0
#define SONIC2PARAM_INT		2

#define SONIC2_PPARAM_FORMAT     "%s%%%d"
#define SONIC2_PNOPARAM_FORMAT   "%s"
#define SONIC2_SCANSTRING_FORMAT "%%%c%%%d%%%d"

typedef struct _sonic2param {
// in = param to send
int pParamType;
char* pNoParamFormat;
char* pParamFormat;
int iParam;
// out = response
char* scanString;
int numArgs;
char token;
char status;
int arg;
} sonic2param_t, *p_sonic2param_t;

//
// function prototypes
//
extern int volatile Sub2SonicCritical;

void alert2Sonic(int gpio, int level, uint32_t tick, void* udata);
int release_2sonic( srv_opts_t *options, p_iic_vars_t i2cVars );
int initialize_2sonic( srv_opts_t *options, p_iic_vars_t i2cVars );
int map2SonicToMasterCode( int CondCode );
int get2SonicCondition( srv_opts_t *options, p_iic_vars_t i2cVars );
int set2SonicCondRedDistance( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int set2SonicCondYellowDistance( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int set2SonicCondGreenDistance( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int get2SonicCondRedDistance( srv_opts_t *options, p_iic_vars_t i2cVars );
int get2SonicCondYellowDistance( srv_opts_t *options, p_iic_vars_t i2cVars );
int get2SonicCondGreenDistance( srv_opts_t *options, p_iic_vars_t i2cVars );
int get2SonicDirection( srv_opts_t *options, p_iic_vars_t i2cVars );
int get2SonicDistance( srv_opts_t *options, p_iic_vars_t i2cVars );
int set2SonicDirectiondForward( srv_opts_t *options, p_iic_vars_t i2cVars );
int set2SonicDirectiondBack( srv_opts_t *options, p_iic_vars_t i2cVars );
int set2SonicInterval( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int get2SonicInterval( srv_opts_t *options, p_iic_vars_t i2cVars );
int set2SonicDirectiondRight( srv_opts_t *options, p_iic_vars_t i2cVars );
int set2SonicDirectiondLeft( srv_opts_t *options, p_iic_vars_t i2cVars );
int do2SonicUserCmd( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int do2SonicStop( srv_opts_t *options, p_iic_vars_t i2cVars );
int do2SonicPause( srv_opts_t *options, p_iic_vars_t i2cVars );
int do2SonicContinue( srv_opts_t *options, p_iic_vars_t i2cVars );
int do2SonicExit( srv_opts_t *options, p_iic_vars_t i2cVars );
int do2SonicStoreValues( srv_opts_t *options, p_iic_vars_t i2cVars );
int set2SonicVerbose( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int set2SonicDirection( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int set2SonicDistance( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int set2SonicCondition( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int set2SonicDebug( srv_opts_t *options, p_iic_vars_t i2cVars, int val );
int set2SonicDefaults( srv_opts_t *options, p_iic_vars_t i2cVars );
int get2SonicMaxAlarm( srv_opts_t *options, p_iic_vars_t i2cVars );
int set2SonicMaxAlarm( srv_opts_t *options, p_iic_vars_t i2cVars, int val );

#endif // _SUBCTL2SONIC_H_

#ifdef __cplusplus
}
#endif


