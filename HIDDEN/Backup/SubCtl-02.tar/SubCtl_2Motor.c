/* *******************************************************************
 *
 * SubCtl_2Motor.c
 *
 * (C) 2014 Dreamshader (Dirk Schanz)
 *
 * control of two dc motors with gears attached
 *     code part
 *
 * -------------------------------------------------------------------
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *******************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <getopt.h>
#include <syslog.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/signal.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/stat.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <termios.h>

#ifndef UBUNTU
#include "pigpio.h"
#endif // NOT UBUNTU

#include "MasterControl.h"
#include "MainCtlThread.h"
#include "SubCtl_2Motor.h"


/*
 * *************************************************************
 * global flag ...
 * *************************************************************
*/


/*
 * *************************************************************
 * release the two sonic module
 * int release_2motor( srv_opts_t *options, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int release_2motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int errcode = E_NOERR;

   if( options != NULL && i2cVars != NULL )
   {
#ifndef UBUNTU
      errcode = i2cClose(i2cVars->i2cHandle2Motor);
#endif // NOT UBUNTU
   }
   else
   {
      errcode = E_NULLPTR;
   }


   return( errcode );
}

/*
 * *************************************************************
 * initialize two sonic module
 * int initialize_2motor( srv_opts_t *options, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int initialize_2motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int errcode = E_NOERR;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL && i2cVars->pParam2motor != NULL )
   {

      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamLFormat   = MOTOR2_PPARAM_LFORMAT;
      motor2Param->pParamIFormat   = MOTOR2_PPARAM_IFORMAT;
      motor2Param->pNoParamFormat = MOTOR2_PNOPARAM_FORMAT;
      motor2Param->scanIString     = MOTOR2_SCANSTRING_IFORMAT;
      motor2Param->scanLString     = MOTOR2_SCANSTRING_LFORMAT;

#ifndef UBUNTU
      i2cVars->i2cHandle2Motor = i2cOpen( I2C_BUS_NO, I2C_SLAVE_2MOTOR, 0);
#endif // NOT UBUNTU
   }
   else
   {
      errcode = E_NULLPTR;
   }


   return( errcode );
}

static motor2_command_set_t motor2Commands[] = {
{ "%g", CMD2MOTOR_GO_UP		 }, // Übergangslos beschleunigen auf max
{ "%G", CMD2MOTOR_GO_DOWN	 }, // Übergangslos abbremsen auf min
{ "%d", CMD2MOTOR_SLOW_DOWN	 }, // Langsam abbremsen auf min
{ "%u", CMD2MOTOR_SPEED_UP	 }, // Langsam beschleunigen auf max
{ "%a", CMD2MOTOR_GO_AHEAD	 }, // Fahrtrichtung setzen vorwaerts
{ "%R", CMD2MOTOR_GO_BACK	 }, // Fahrtrichtung setzen rueckwaerts
{ "%l", CMD2MOTOR_TURN_LEFT	 }, // Fahrtrichtung setzen links 0-90°
{ "%r", CMD2MOTOR_TURN_RIGHT	 }, // Fahrtrichtung setzen rechts 0-90°
{ "%D", CMD2MOTOR_GET_DIRECTION  }, // Fahrtrichtung holen
{ "%x", CMD2MOTOR_STOP		 }, // Stop
{ "%X", CMD2MOTOR_BREAK		 }, // Bremsen
{ "%W", CMD2MOTOR_STORE_VALUES	 }, // Werte in EEPROM schreiben
{ "%L", CMD2MOTOR_RESTORE_VALUES }, // Werte aus EEPROM lesen
{ "%V", CMD2MOTOR_SET_VERBOSE	 }, // Protokoll-Modus
{ "%T", CMD2MOTOR_SET_DEBUG	 }, // Debug Modus
{ "%N", CMD2MOTOR_SET_SERIALBAUD }, // Baudrate rs232 setzen
{ "%n", CMD2MOTOR_GET_SERIALBAUD }, // Baudrate rs232 holen
{ "%Y", CMD2MOTOR_RESET_DEFAULTS }, // auf defaults zurücksetzen (factory)
{ "%u", CMD2MOTOR_USER		 }, // user-Kommando
{ "%S", CMD2MOTOR_SET_SYNC_ON	 }, // synchron ein
{ "%O", CMD2MOTOR_SET_SYNC_OFF	 }, // synchron aus
{ "%A", CMD2MOTOR_SET_SYNC_AUTO	 }, // synchron automatik
{ "%s", CMD2MOTOR_GET_SYNC	 }, // hole synchron status
{ "%p", CMD2MOTOR_SET_POWER	 }, // setze Geschwindigkeit 0-100%
{ "%f", CMD2MOTOR_SET_POWER_R	 }, // setze Geschwindigkeit rechts 0-100%
{ "%F", CMD2MOTOR_SET_POWER_L	 }, // setze Geschwindigkeit links 0-100%
{ "%P", CMD2MOTOR_GET_POWER	 }, // hole Geschwindigkeit
{ "%z", CMD2MOTOR_GET_POWER_R	 }, // hole Geschwindigkeit rechts
{ "%Z", CMD2MOTOR_GET_POWER_L	 }, // hole Geschwindigkeit links
{ "%q", CMD2MOTOR_GET_ROT_R	 }, // hole Umdrehungen gesamt rechts
{ "%Q", CMD2MOTOR_GET_ROT_L	 }, // hole Umdrehungen gesamt links
{ "%m", CMD2MOTOR_GET_MOT_R	 }, // hole zurückgelegte Strecke rechts
{ "%M", CMD2MOTOR_GET_MOT_L	 }, // hole zurückgelegte Strecke links
{ "%I", CMD2MOTOR_RESET_MOTION	 }, // Umdrehungen und Distanz zurücksetzen
{ "%c", CMD2MOTOR_SOFTRESET	 }, // coldstart zurückgelegte Strecke links
{ "%K", CMD2MOTOR_EXIT		 }, // stop program
{ NULL, 0 }
};

/*
 * *************************************************************
 * find a specific command token in command set
 * *************************************************************
*/
int find2MotorCmd( int cmdVal )
{
   int i, tokenIdx;

   for(i = 0, tokenIdx = -1; motor2Commands[i].cmd != NULL && tokenIdx < 0; i++ )
   {
      if( motor2Commands[i].cmd_val == cmdVal )
      {
         tokenIdx = i;
      }
   }
   return(tokenIdx);
}

/*
 * *************************************************************
 * map 2motor specific condition code to MasterCtl Code
 * int map2MotorToMasterCode( int CondCode )
 * *************************************************************
*/
int map2MotorToMasterCode( int CondCode )
{
   int MapCode = 0;

// #define CONDITION_2MOTOR_R	3
// #define CONDITION_2MOTOR_Y	4
// #define CONDITION_2MOTOR_G	5

   return( MapCode );
}


void prepare2MotorCmd( int cmdIdx, p_iic_vars_t i2cVars )
{
   p_motor2param_t motor2Param;

   if( i2cVars != NULL && i2cVars->pParam2motor != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
 
      if( motor2Param->pParamType == MOTOR2PARAM_NONE )
      {
         sprintf(i2cVars->i2cOutBuf, 
                 motor2Param->pNoParamFormat, motor2Commands[cmdIdx].cmd );
      }
      else
      {
         if( motor2Param->pParamType == MOTOR2PARAM_LONG )
         {
            sprintf(i2cVars->i2cOutBuf, 
                    motor2Param->pParamLFormat,
                    motor2Commands[cmdIdx].cmd,
                    motor2Param->iParam );
         }
         else
         {
            sprintf(i2cVars->i2cOutBuf, 
                    motor2Param->pParamIFormat,
                    motor2Commands[cmdIdx].cmd,
                    motor2Param->iParam );
         }
      }
   }
}

/*
 * *************************************************************
 * send a command to the subcontroller using iic bus
 * int send2MotorCmd( int cmdIdx, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int send2MotorCmd( int cmdIdx, p_iic_vars_t i2cVars )
{
   int errcode = E_NOERR;
   char *ptr;
   int rc;

   if( i2cVars != NULL )
   {
#ifndef UBUNTU
      rc = i2cWriteDevice(i2cVars->i2cHandle2Motor, i2cVars->i2cOutBuf,
                           strlen(i2cVars->i2cOutBuf) );
      memset(i2cVars->i2cInBuf, '\0', sizeof(i2cVars->i2cInBuf));
      rc = i2cReadDevice(i2cVars->i2cHandle2Motor, i2cVars->i2cInBuf, I2C_MSG_LEN);

      if( (ptr = strchr(i2cVars->i2cInBuf, 0x0ff)) != NULL )
      {
         *ptr = '\0';
      }
#endif // NOT UBUNTU
   }
   else
   {
      errcode = E_NULLPTR;
   }

   return(errcode);
}

/*
 * *************************************************************
 * process a specific comand 
 * int process2MotorCommand( int cmdVal, srv_opts_t *options,
 *                           p_iic_vars_t i2cVars,
 *                           motor2param_t* pParam )
 * *************************************************************
*/
int process2MotorCommand( int cmdVal, srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition = E_NOERR;
   p_motor2param_t motor2Param;
   int cmdIdx;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      if( (cmdIdx = find2MotorCmd( cmdVal )) >= 0 )
      {
         prepare2MotorCmd( cmdIdx, i2cVars );
         if( (condition = send2MotorCmd( cmdIdx, i2cVars )) >= 0 )
         {
            motor2Param->numArgs = sscanf(i2cVars->i2cInBuf,
                 motor2Param->scanIString, &motor2Param->token,
                 &motor2Param->status, &motor2Param->arg );
// long unt int!!!
fprintf(stderr, "cmd sent, num args = %d, token = %c, status = %c, arg = %d [%s]\n", motor2Param->numArgs, (char) motor2Param->token, (char) (motor2Param->status + '0'), motor2Param->arg, i2cVars->i2cInBuf );

         }
      }
      else
      {
         condition = E_NOCOMMAND;
      }
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int goUp2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int max )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = max;

      condition = process2MotorCommand( CMD2MOTOR_GO_UP, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int goDown2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int min )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = min;

      condition = process2MotorCommand( CMD2MOTOR_GO_DOWN, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int slowDown2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int min )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = min;

      condition = process2MotorCommand( CMD2MOTOR_SLOW_DOWN, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int speedUp2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int max )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = max;

      condition = process2MotorCommand( CMD2MOTOR_SPEED_UP, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int goAhead2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GO_AHEAD, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int goBack2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GO_BACK, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int turnLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int degree )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = degree;

      condition = process2MotorCommand( CMD2MOTOR_TURN_LEFT, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int turnRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int degree )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = degree;

      condition = process2MotorCommand( CMD2MOTOR_TURN_RIGHT, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int getDirection2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_DIRECTION, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int stop2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_STOP, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int break2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_BREAK, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int storeValues2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_STORE_VALUES, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int restoreValues2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_RESTORE_VALUES, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int verbose2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int level )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = level;

      condition = process2MotorCommand( CMD2MOTOR_SET_VERBOSE, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int debug2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int level )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = level;

      condition = process2MotorCommand( CMD2MOTOR_SET_DEBUG, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int setSerialBaud2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, long baudrate )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_LONG;
      motor2Param->lParam = baudrate;

      condition = process2MotorCommand( CMD2MOTOR_SET_SERIALBAUD, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
long getSerialBaud2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_SERIALBAUD, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int resetDefaults2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_RESET_DEFAULTS, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int doUserCmd2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int cmd )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = cmd;

      condition = process2MotorCommand( CMD2MOTOR_USER, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int syncOn2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_SET_SYNC_ON, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int syncOff2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_SET_SYNC_OFF, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int syncAuto2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_SET_SYNC_AUTO, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int getSync2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_SYNC, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int setPower2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int percent )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = percent;

      condition = process2MotorCommand( CMD2MOTOR_SET_POWER, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int setPowerRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int percent )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = percent;

      condition = process2MotorCommand( CMD2MOTOR_SET_POWER_R, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int setPowerLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int percent )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_INT;
      motor2Param->iParam = percent;

      condition = process2MotorCommand( CMD2MOTOR_SET_POWER_L, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int getPower2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_POWER, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int getPowerRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_POWER_R, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int getPowerLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_POWER_L, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
long getRotationsRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_ROT_R, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
long getRotationsLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_ROT_L, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
long getMotionRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_MOT_R, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
long getMotionLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_GET_MOT_L, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int doSoftReset2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_SOFTRESET, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


/*
 * *************************************************************
 * 
 * *************************************************************
*/
int doExitProgram2Motor( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_motor2param_t motor2Param;

   if( options != NULL && i2cVars != NULL )
   {
      motor2Param = (p_motor2param_t) i2cVars->pParam2motor;
      motor2Param->pParamType = MOTOR2PARAM_NONE;

      condition = process2MotorCommand( CMD2MOTOR_EXIT, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

