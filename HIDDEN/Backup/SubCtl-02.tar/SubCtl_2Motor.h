/* *******************************************************************
 *
 * SubCtl_2Motor.h
 *
 * (C) 2014 Dreamshader (Dirk Schanz)
 *
 * control of two dc motors with gear
 *     definitions and prototypes
 *
 * -------------------------------------------------------------------
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *******************************************************************
*/

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _SUBCTL2MOTOR_H_
#define _SUBCTL2MOTOR_H_

//
// constant definitions
//
#define CMD2MOTOR_GO_UP			 1
#define CMD2MOTOR_GO_DOWN		 2
#define CMD2MOTOR_SLOW_DOWN		 3
#define CMD2MOTOR_SPEED_UP		 4
#define CMD2MOTOR_GO_AHEAD		 5
#define CMD2MOTOR_GO_BACK		 6
#define CMD2MOTOR_TURN_LEFT		 7
#define CMD2MOTOR_TURN_RIGHT		 8
#define CMD2MOTOR_GET_DIRECTION		 9
#define CMD2MOTOR_STOP			10
#define CMD2MOTOR_BREAK			11
#define CMD2MOTOR_STORE_VALUES		12
#define CMD2MOTOR_RESTORE_VALUES	13
#define CMD2MOTOR_SET_VERBOSE		14
#define CMD2MOTOR_SET_DEBUG		15
#define CMD2MOTOR_SET_SERIALBAUD	16
#define CMD2MOTOR_GET_SERIALBAUD	17
#define CMD2MOTOR_RESET_DEFAULTS	18
#define CMD2MOTOR_USER			19
#define CMD2MOTOR_SET_SYNC_ON		20
#define CMD2MOTOR_SET_SYNC_OFF		21
#define CMD2MOTOR_SET_SYNC_AUTO		22
#define CMD2MOTOR_GET_SYNC		23
#define CMD2MOTOR_SET_POWER		24
#define CMD2MOTOR_SET_POWER_R		25
#define CMD2MOTOR_SET_POWER_L		26
#define CMD2MOTOR_GET_POWER		27
#define CMD2MOTOR_GET_POWER_R		28
#define CMD2MOTOR_GET_POWER_L		29
#define CMD2MOTOR_GET_ROT_R		30
#define CMD2MOTOR_GET_ROT_L		31
#define CMD2MOTOR_GET_MOT_R		32
#define CMD2MOTOR_GET_MOT_L		33
#define CMD2MOTOR_RESET_MOTION		34
#define CMD2MOTOR_SOFTRESET		35
#define CMD2MOTOR_EXIT			36


typedef struct _2motor_command_set_ {
char *cmd;
int cmd_val;
} motor2_command_set_t, *p_2motor_command_set_t;


#define MOTOR2PARAM_NONE	0
#define MOTOR2PARAM_INT		2
#define MOTOR2PARAM_LONG	4

#define MOTOR2_PPARAM_IFORMAT      "%s%%%d"
#define MOTOR2_PPARAM_LFORMAT      "%s%%%l"
#define MOTOR2_PNOPARAM_FORMAT    "%s"
#define MOTOR2_SCANSTRING_IFORMAT "%%%c%%%d%%%d"
#define MOTOR2_SCANSTRING_LFORMAT "%%%c%%%d%%%l"

typedef struct _motor2param {
// in = param to send
int pParamType;
char* pNoParamFormat;
char* pParamLFormat;
char* pParamIFormat;
int iParam;
long lParam;
// out = response
char* scanIString;
char* scanLString;
int numArgs;
char token;
char status;
int arg;
} motor2param_t, *p_motor2param_t;

//
// function prototypes
//

int goUp2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int max );
int goDown2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int min );
int slowDown2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int min );
int speedUp2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int max );
int goAhead2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int goBack2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int turnLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int degree );
int turnRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int degree );
int getDirection2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int stop2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int break2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int storeValues2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int restoreValues2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int verbose2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int level );
int debug2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int level );
int setSerialBaud2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, long baudrate );
long getSerialBaud2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int resetDefaults2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int doUserCmd2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int cmd );
int syncOn2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int syncOff2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int syncAuto2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int getSync2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int setPower2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int percent );
int setPowerRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int percent );
int setPowerLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars, int percent );
int getPower2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int getPowerRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int getPowerLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
long getRotationsRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
long getRotationsLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
long getMotionRight2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
long getMotionLeft2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int doSoftReset2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );
int doExitProgram2Motor( srv_opts_t *options, p_iic_vars_t i2cVars );

#endif // _SUBCTL2MOTOR_H_

#ifdef __cplusplus
}
#endif


