/* *******************************************************************
 *
 * SubCtl_2Sonic.c
 *
 * (C) 2014 Dreamshader (Dirk Schanz)
 *
 * control of an ultrasonic subcontroller (pro mini with two us-sensors)
 *     code part
 *
 * -------------------------------------------------------------------
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *******************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <getopt.h>
#include <syslog.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/signal.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/stat.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <termios.h>

#ifndef UBUNTU
#include "pigpio.h"
#endif // NOT UBUNTU

#include "MasterControl.h"
#include "MainCtlThread.h"
#include "SubCtl_2Sonic.h"


/*
 * *************************************************************
 * global flag ...
 * *************************************************************
*/
int volatile Sub2SonicCritical;

/*
 * *************************************************************
 * handler for critical condition -> set flag
 * *************************************************************
*/
void alert2Sonic(int gpio, int level, uint32_t tick, void* udata)
{
  Sub2SonicCritical = 1;
//    printf("gpio %d became %d at %d\n", gpio, level, tick);
}

/*
 * *************************************************************
 * release the two sonic module
 * int release_2sonic( srv_opts_t *options, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int release_2sonic( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int errcode = E_NOERR;

   if( options != NULL && i2cVars != NULL )
   {
#ifndef UBUNTU
      errcode = i2cClose(i2cVars->i2cHandle2Sonic);
#endif // NOT UBUNTU
   }
   else
   {
      errcode = E_NULLPTR;
   }


   return( errcode );
}

/*
 * *************************************************************
 * initialize two sonic module
 * int initialize_2sonic( srv_opts_t *options, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int initialize_2sonic( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int errcode = E_NOERR;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL && i2cVars->pParam2sonic != NULL )
   {

      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamFormat   = SONIC2_PPARAM_FORMAT;
      sonic2Param->pNoParamFormat = SONIC2_PNOPARAM_FORMAT;
      sonic2Param->scanString     = SONIC2_SCANSTRING_FORMAT;
#ifndef UBUNTU
      i2cVars->i2cHandle2Sonic = i2cOpen( I2C_BUS_NO, I2C_SLAVE_2SONIC, 0);

      gpioSetMode(PIN_ALARM_2SONIC, PI_INPUT);
//      gpioSetPullUpDown(PIN_ALARM_2SONIC, PI_PUD_UP);
      gpioSetAlertFuncEx(PIN_ALARM_2SONIC, alert2Sonic, i2cVars);
//     gpioSetAlertFuncEx(PIN_ALARM_2SONIC, alertSonic, void* userdata);
#endif // NOT UBUNTU
   }
   else
   {
      errcode = E_NULLPTR;
   }


   return( errcode );
}

static sonic2_command_set_t sonic2Commands[] = {
{ "%d",	CMD2SONIC_GET_DIRECTION },
{ "%D",	CMD2SONIC_GET_DISTANCE },
{ "%C",	CMD2SONIC_GET_CONDITION },
{ "%A",	CMD2SONIC_SET_COND_R_DIST },
{ "%W",	CMD2SONIC_SET_COND_Y_DIST },
{ "%G",	CMD2SONIC_SET_COND_G_DIST },
{ "%a",	CMD2SONIC_GET_COND_R_DIST },
{ "%w",	CMD2SONIC_GET_COND_Y_DIST },
{ "%g",	CMD2SONIC_GET_COND_G_DIST },
{ "%f",	CMD2SONIC_SET_DIR_FORWARD },
{ "%b",	CMD2SONIC_SET_DIR_BACK },
{ "%i",	CMD2SONIC_SET_INTERVAL },
{ "%I",	CMD2SONIC_GET_INTERVAL },
{ "%r",	CMD2SONIC_SET_DIR_RIGHT },
{ "%l",	CMD2SONIC_SET_DIR_LEFT },
{ "%u",	CMD2SONIC_USER },
{ "%s",	CMD2SONIC_STOP },
{ "%p",	CMD2SONIC_PAUSE },
{ "%c",	CMD2SONIC_CONTINUE },
{ "%x",	CMD2SONIC_EXIT },
{ "%S",	CMD2SONIC_STORE_VALUES },
{ "%V",	CMD2SONIC_SET_VERBOSE },
{ "%H", CMD2SONIC_SET_DIRECTION },
{ "%P", CMD2SONIC_SET_DISTANCE },
{ "%Z", CMD2SONIC_SET_CONDITION },
{ "%T", CMD2SONIC_SET_DEBUG },
{ "%R", CMD2SONIC_RESET_DEFAULTS },
{ "%n", CMD2SONIC_GET_MAXALARM },
{ "%N", CMD2SONIC_SET_MAXALARM },
// todo:
// restore from eeprom
// coldstart = soft reset
{ NULL,	0 }
};

/*
 * *************************************************************
 * find a specific command token in command set
 * *************************************************************
*/
int find2SonicCmd( int cmdVal )
{
   int i, tokenIdx;

   for(i = 0, tokenIdx = -1; sonic2Commands[i].cmd != NULL && tokenIdx < 0; i++ )
   {
      if( sonic2Commands[i].cmd_val == cmdVal )
      {
         tokenIdx = i;
      }
   }
   return(tokenIdx);
}

/*
 * *************************************************************
 * map 2sonic specific condition code to MasterCtl Code
 * int map2SonicToMasterCode( int CondCode )
 * *************************************************************
*/
int map2SonicToMasterCode( int CondCode )
{
   int MapCode = 0;

// #define CONDITION_2SONIC_R	3
// #define CONDITION_2SONIC_Y	4
// #define CONDITION_2SONIC_G	5

   return( MapCode );
}


void prepare2SonicCmd( int cmdIdx, p_iic_vars_t i2cVars )
{
   p_sonic2param_t sonic2Param;

   if( i2cVars != NULL && i2cVars->pParam2sonic != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
 
      if( sonic2Param->pParamType == SONIC2PARAM_NONE )
      {
         sprintf(i2cVars->i2cOutBuf, 
                 sonic2Param->pNoParamFormat, sonic2Commands[cmdIdx].cmd );
      }
      else
      {
         sprintf(i2cVars->i2cOutBuf, 
                 sonic2Param->pParamFormat,
                 sonic2Commands[cmdIdx].cmd,
                 sonic2Param->iParam );
      }
   }
}

/*
 * *************************************************************
 * send a command to the subcontroller using iic bus
 * int send2SonicCmd( int cmdIdx, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int send2SonicCmd( int cmdIdx, p_iic_vars_t i2cVars )
{
   int errcode = E_NOERR;
   char *ptr;
   int rc;

   if( i2cVars != NULL )
   {
#ifndef UBUNTU
      rc = i2cWriteDevice(i2cVars->i2cHandle2Sonic, i2cVars->i2cOutBuf,
                           strlen(i2cVars->i2cOutBuf) );
      memset(i2cVars->i2cInBuf, '\0', sizeof(i2cVars->i2cInBuf));
      rc = i2cReadDevice(i2cVars->i2cHandle2Sonic, i2cVars->i2cInBuf, I2C_MSG_LEN);

      if( (ptr = strchr(i2cVars->i2cInBuf, 0x0ff)) != NULL )
      {
         *ptr = '\0';
      }
#endif // NOT UBUNTU
   }
   else
   {
      errcode = E_NULLPTR;
   }

   return(errcode);
}

/*
 * *************************************************************
 * process a specific comand 
 * int process2SonicCommand( int cmdVal, srv_opts_t *options,
 *                           p_iic_vars_t i2cVars,
 *                           sonic2param_t* pParam )
 * *************************************************************
*/
int process2SonicCommand( int cmdVal, srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition = CONDITION_2SONIC_G;
   p_sonic2param_t sonic2Param;
   int cmdIdx;

   if( options != NULL && i2cVars != NULL )
   {
      if( Sub2SonicCritical )
      {
         // fprintf(stderr, "CRITICAL CONDITION!\n");
         Sub2SonicCritical = 0;
         condition = CONDITION_2SONIC_R;
      }
      else
      {
         sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
         if( (cmdIdx = find2SonicCmd( cmdVal )) >= 0 )
         {
            prepare2SonicCmd( cmdIdx, i2cVars );
            if( (condition = send2SonicCmd( cmdIdx, i2cVars )) >= 0 )
            {
               sonic2Param->numArgs = sscanf(i2cVars->i2cInBuf,
                    sonic2Param->scanString, &sonic2Param->token,
                    &sonic2Param->status, &sonic2Param->arg );

fprintf(stderr, "cmd sent, num args = %d, token = %c, status = %c, arg = %d [%s]\n", sonic2Param->numArgs, (char) sonic2Param->token, (char) (sonic2Param->status + '0'), sonic2Param->arg, i2cVars->i2cInBuf );

            }
         }
         else
         {
            condition = E_NOCOMMAND;
         }
      }
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * get current sonic condition
 * int get2SonicCondition( srv_opts_t *options, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int get2SonicCondition( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;


   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_GET_CONDITION, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }
   return(condition);
}

/*
 * *************************************************************
 * set limit for red condition
 * int set2SonicCondRedDistance( srv_opts_t *options, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int set2SonicCondRedDistance( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;


   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_COND_R_DIST, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }
   return(condition);
}

/*
 * *************************************************************
 * set limit for yellow condition
 * int set2SonicCondYellowDistance(srv_opts_t *options, p_iic_vars_t i2cVars)
 * *************************************************************
*/
int set2SonicCondYellowDistance( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_COND_Y_DIST, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }
   return(condition);
}


/*
 * *************************************************************
 * set limit for green condition
 * int set2SonicCondGreenRedDistance(srv_opts_t *options,p_iic_vars_t i2cVars)
 * *************************************************************
*/
int set2SonicCondGreenDistance( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_COND_G_DIST, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }
   return(condition);
}
/*
 * *************************************************************
 * get limit for red condition
 * int get2SonicCondRedDistance( srv_opts_t *options, p_iic_vars_t i2cVars )
 * *************************************************************
*/
int get2SonicCondRedDistance( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_GET_COND_R_DIST, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }
   return(condition);
}

/*
 * *************************************************************
 * get limit for yellow condition
 * int get2SonicCondYellowDistance(srv_opts_t *options, p_iic_vars_t i2cVars)
 * *************************************************************
*/
int get2SonicCondYellowDistance( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_GET_COND_Y_DIST, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }
   return(condition);
}


/*
 * *************************************************************
 * get limit for green condition
 * int get2SonicCondGreenRedDistance(srv_opts_t *options,p_iic_vars_t i2cVars)
 * *************************************************************
*/
int get2SonicCondGreenDistance( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_GET_COND_G_DIST, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }
   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int get2SonicDirection( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_GET_DIRECTION, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int get2SonicDistance( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_GET_DISTANCE, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicDirectiondForward( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_SET_DIR_FORWARD, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicDirectiondBack( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_SET_DIR_BACK, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicInterval( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_INTERVAL, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int get2SonicInterval( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_GET_INTERVAL, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicDirectiondRight( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_SET_DIR_RIGHT, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicDirectiondLeft( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_SET_DIR_LEFT, options,
                                        i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int do2SonicUserCmd( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_USER, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int do2SonicStop( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_STOP, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int do2SonicPause( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_PAUSE, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int do2SonicContinue( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_CONTINUE, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int do2SonicExit( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_EXIT, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int do2SonicStoreValues( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_STORE_VALUES, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicVerbose( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_VERBOSE, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicDirection( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_DIRECTION, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicDistance( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_DISTANCE, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicCondition( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_CONDITION, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicDebug( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_DEBUG, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicDefaults( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_RESET_DEFAULTS, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int set2SonicMaxAlarm( srv_opts_t *options, p_iic_vars_t i2cVars, int val )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_INT;
      sonic2Param->iParam = val;

      condition = process2SonicCommand( CMD2SONIC_SET_MAXALARM, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}

/*
 * *************************************************************
 * 
 * *************************************************************
*/
int get2SonicMaxAlarm( srv_opts_t *options, p_iic_vars_t i2cVars )
{
   int condition;
   p_sonic2param_t sonic2Param;

   if( options != NULL && i2cVars != NULL )
   {
      sonic2Param = (p_sonic2param_t) i2cVars->pParam2sonic;
      sonic2Param->pParamType = SONIC2PARAM_NONE;

      condition = process2SonicCommand( CMD2SONIC_GET_MAXALARM, options, i2cVars );
   }
   else
   {
      condition = E_NULLPTR;
   }

   return(condition);
}


